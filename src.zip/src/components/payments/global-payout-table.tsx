'use client';

import { ServerSideTable, type ColumnDef } from '@/components/ui/server-side-table';
import { Badge } from '@/components/ui/badge';
import { formatStatusLabel } from '@/lib/utils';
import type { PaginatedResponse } from '@/types';

export interface GlobalPayoutRecord {
  id: string;
  createdAt: string;
  status: string;
  amount: number | string;
  periodStart: string | null;
  periodEnd: string | null;
  module?: string;
  supplier?: {
    companyName?: string;
    email?: string;
  };
  details?: {
    breakdown?: {
      cab?: number;
      carRental?: number;
      bikeRental?: number;
    };
  };
}

interface GlobalPayoutTableProps {
  data: PaginatedResponse<GlobalPayoutRecord> | undefined | null;
  loading: boolean;
  page: number;
  limit: number;
  onPageChange: (page: number) => void;
  onLimitChange: (limit: number) => void;
}

function formatDate(isoStr: string | null | undefined): string {
  if (!isoStr) return '—';
  const date = new Date(isoStr);
  const day = date.getDate().toString().padStart(2, '0');
  const month = date.toLocaleString('en-US', { month: 'short' });
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}

export function GlobalPayoutTable({
  data,
  loading,
  page,
  limit,
  onPageChange,
  onLimitChange,
}: GlobalPayoutTableProps) {
  const columns: ColumnDef<GlobalPayoutRecord>[] = [
    {
      key: 'createdAt',
      title: 'DATE',
      render: (row) => (
        <span className="text-sm text-[#9CA3AF] font-mono">
          {formatDate(row.createdAt)}
        </span>
      ),
    },
    {
      key: 'supplier',
      title: 'SUPPLIER',
      render: (row) => (
        <div className="flex flex-col">
          <span className="text-sm font-medium text-white">
            {row.supplier?.companyName || 'N/A'}
          </span>
          <span className="text-xs text-[#6B7280]">{row.supplier?.email}</span>
        </div>
      ),
    },
    {
      key: 'period',
      title: 'SETTLEMENT PERIOD',
      render: (row) => (
        <span className="text-sm text-[#9CA3AF]">
          {formatDate(row.periodStart)} to {formatDate(row.periodEnd)}
        </span>
      ),
    },
    {
      key: 'amount',
      title: 'AMOUNT',
      render: (row) => (
        <span className="text-sm font-semibold text-[#22C55E]">
          €{Number(row.amount).toFixed(2)}
        </span>
      ),
    },
    {
      key: 'status',
      title: 'STATUS',
      render: (row) => {
        let badgeClass = 'border-gray-500/20 bg-gray-500/10 text-gray-400';
        if (row.status === 'COMPLETED') badgeClass = 'border-[#22C55E]/20 bg-[#22C55E]/10 text-[#22C55E]';
        if (row.status === 'PENDING') badgeClass = 'border-[#FACC15]/20 bg-[#FACC15]/10 text-[#FACC15]';
        if (row.status === 'PROCESSING') badgeClass = 'border-[#3B82F6]/20 bg-[#3B82F6]/10 text-[#3B82F6]';
        if (row.status === 'FAILED') badgeClass = 'border-[#EF4444]/20 bg-[#EF4444]/10 text-[#EF4444]';

        return (
          <Badge className={`px-2.5 py-0.5 text-xs font-semibold capitalize ${badgeClass}`}>
            {formatStatusLabel(row.status)}
          </Badge>
        );
      },
    },
  ];

  const renderExpandedRow = (row: GlobalPayoutRecord) => {
    const cab = Number(row.details?.breakdown?.cab || 0);
    const carRental = Number(row.details?.breakdown?.carRental || 0);
    const bikeRental = Number(row.details?.breakdown?.bikeRental || 0);

    return (
      <div className="p-4 bg-[#0A0A0A] border-t border-[#27272A] rounded-b-lg shadow-inner">
        <p className="text-xs font-semibold text-[#A1A1AA] mb-3 uppercase tracking-wider">Global Payout Breakdown</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-[#141414] border border-[#27272A] p-3 rounded-lg flex justify-between items-center">
            <span className="text-sm text-[#D4D4D8]">Cab Bookings</span>
            <span className="text-sm font-semibold text-white">€{cab.toFixed(2)}</span>
          </div>
          <div className="bg-[#141414] border border-[#27272A] p-3 rounded-lg flex justify-between items-center">
            <span className="text-sm text-[#D4D4D8]">Car Rentals</span>
            <span className="text-sm font-semibold text-white">€{carRental.toFixed(2)}</span>
          </div>
          <div className="bg-[#141414] border border-[#27272A] p-3 rounded-lg flex justify-between items-center">
            <span className="text-sm text-[#D4D4D8]">Bike Rentals</span>
            <span className="text-sm font-semibold text-white">€{bikeRental.toFixed(2)}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <ServerSideTable
      columns={columns}
      data={data?.data || []}
      isLoading={loading}
      page={page}
      limit={limit}
      total={data?.meta?.total || 0}
      onPageChange={onPageChange}
      onLimitChange={onLimitChange}
      emptyText="No payouts found."
      renderExpandedRow={renderExpandedRow}
    />
  );
}
